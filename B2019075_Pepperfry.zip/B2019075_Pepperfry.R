sales <- read_excel("C:/Users/Gokul Mohan/Downloads/css.xlsx", 
                    sheet = "Sale")

inventory <- read_excel("C:/Users/Gokul Mohan/Downloads/css.xlsx", 
                        sheet = "Inventory")


#make the 3rd column as the header
names(inventory) <- as.matrix(inventory[3, ])
View(inventory)

#exclude the 1st, 2nd, 3rd column
inventory <- inventory[-c(1,2,3), ]

View(sales)

lapply(inventory, class)
inventory = as.numeric(as.character(7:64))
str(7:64)

week_inventory = colSums(inventory[,7:64])
cbind(rownames(inventory[,7:64]),)

View(new)

library(forecast)
library(tidyverse)
library(tseries)
library(caTools)

#dividing the new dataset into training and testing 
set.seed(123)
tsdata =sample.split(new,SplitRatio=0.8)

#time series
tsData <- c(19
            ,25
            ,20
            ,18
            ,21
            ,22
            ,29
            ,27
            ,1932
            ,1989
            ,1997
            ,2043
            ,2123
            ,2017.5
            ,2294
            ,2183
            ,2227
            ,2100.282
            ,2064
            ,2002
            ,1873
            ,1817
            ,1686
            ,1542
            ,1573
            ,1396
            ,1386
            ,1524
            ,1485
            ,1383
            ,1238
            ,1166
            ,1130
            ,1243
            ,1168
            ,1264
            ,1149
            ,1103
            ,1065
            ,1228
            ,1286
            ,1219
            ,1252
            ,1255
            ,1177
            ,1132
            ,1161
            ,1241
            ,1216
            ,1289
            ,1211
            ,1129
            ,1262
            ,1172
            ,1221
            ,1310
            ,1279
            ,1211
)




#time series
ts <- ts(tsData, frequency = 4)
plot(ts)
sm <- summary(ts)
sm
accuracy(forecast(ts), test=NULL, d=NULL, D=NULL)


#decompostion of additive time series
plot(decompose(ts))
#first is random, second is seasonal, third is trend, fourth is observed (bottom to up)


#auto.arima
fit1 <- auto.arima(ts)
plot(forecast(fit1,h=20))

accuracy(fit1)

#auto.arima seasonal
fit_s<-auto.arima(ts, seasonal=TRUE)
plot(forecast(fit_s,h=20))

accuracy(fit_s)

# Holt winters simple exponential - models level
fit2 <- HoltWinters(tsData, beta=FALSE, gamma=FALSE)
accuracy(forecast(fit2), test=NULL, d=NULL, D=NULL)

# Holt winters double exponential - models level and trend
fit3 <- HoltWinters(tsData, gamma=FALSE)
accuracy(forecast(fit3), test=NULL, d=NULL, D=NULL)

plot(fit2)
plot(fit3)


# predict next three future values
library(forecast)
forecast(fit, 3)
plot(forecast(fit, 3))


#sales forecasting
#timeseries
tsdatasales<-c(231,190,169,182,186,198,179,225,190,210,234,280,261,238,213,242,185,266,258,238,217,238,330,223,256,204,199,186,253,179,165,168,150,150,186,231,172,202,181,241,254,246,
               59,78,91,108,92,123,93,100,95,90,89,85,95,141,81,106,77,93,101,129)



#time series
ts_sales <- ts(tsdatasales, frequency = 4)
plot(ts_sales)
sm <- summary(ts_sales)
sm

#decompostion of additive time series
plot(decompose(ts_sales))
#first is random, second is seasonal, third is trend, fourth is observed (bottom to up)


#auto.arima
fit4 <- auto.arima(ts_sales)
plot(forecast(fit4,h=20))


#auto.arima seasonal
fit_s<-auto.arima(ts_sales, seasonal=TRUE)
plot(forecast(fit_s,h=20))
accuracy(forecast(fit_s), test=NULL, d=NULL, D=NULL)

# Holt winters simple exponential - models level
fit9 <- HoltWinters(tsdatasales, beta=FALSE, gamma=FALSE)
# Holt winters double exponential - models level and trend
fit10 <- HoltWinters(tsdatasales, gamma=FALSE)
plot(fit9)
plot(fit10)
accuracy(forecast(fit9), test=NULL, d=NULL, D=NULL)
accuracy(forecast(fit10), test=NULL, d=NULL, D=NULL)

# predict next three future values
library(forecast)
forecast(fit, 3)
plot(forecast(fit, 3))



